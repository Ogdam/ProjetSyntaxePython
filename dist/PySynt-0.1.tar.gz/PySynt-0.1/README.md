## Projet Compilateur Python

 ### Phase I -> tokenizer

  Séparation du code en token suivant
    * les mots clefs / variables
    * la typologie du Python

 ### Phase II -> Analyse syntaxique ( ASL )
    * [ ] : définitions de fonctions
    * [ ] boucle/test
    * [x] = affectation
    * [ ] > / < / <= / >= / == / is not / is -> test d'égalité
    * [ ] {}  Dictionnaire
    * [ ] ()  Tuples
    * [ ] \[\]  Liste
    * [ ] tabulation
